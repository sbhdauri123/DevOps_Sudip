This directory contains an interactive slideshow that you can view in your browser. Open the index.html file in a web browser and use the arrow keys to navigate. `P` will toggle presentation mode, and `C` will launch a separate window with only slide content.

